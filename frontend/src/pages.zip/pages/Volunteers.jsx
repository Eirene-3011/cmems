import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiX, FiHeart } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

function statusBadge(s) {
  if (s === 'Confirmed')  return 'badge-green';
  if (s === 'Completed')  return 'badge-blue';
  if (s === 'No Show')    return 'badge-red';
  return 'badge-yellow';
}

export default function Volunteers() {
  const { user }                = useAuth();
  const [volunteers, setVolunteers] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [members, setMembers]   = useState([]);
  const [events, setEvents]     = useState([]);
  const [tab, setTab]           = useState('volunteers');
  const [volModal, setVolModal] = useState(false);
  const [assModal, setAssModal] = useState(false);

  const canWrite = ['Super Administrator','Ministry Leader'].includes(user?.role);

  async function load() {
    const [vr, ar, mr, er] = await Promise.all([
      api.get('/volunteers'),
      api.get('/volunteers/assignments'),
      api.get('/members'),
      api.get('/events'),
    ]);
    setVolunteers(vr.data.data);
    setAssignments(ar.data.data);
    setMembers(mr.data.data);
    setEvents(er.data.data);
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Volunteers</h1>
        {canWrite && (
          <div className="flex gap-2">
            <button onClick={() => setVolModal(true)} className="btn-secondary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Register Volunteer</button>
            <button onClick={() => setAssModal(true)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Assign</button>
          </div>
        )}
      </div>

      <div className="flex gap-2 border-b pb-0">
        {['volunteers','assignments'].map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${tab === t ? 'border-primary-600 text-primary-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {t === 'volunteers' ? 'Volunteers' : 'Assignments'}
          </button>
        ))}
      </div>

      {tab === 'volunteers' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {volunteers.map(v => (
            <div key={v.id} className="card">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                  <FiHeart className="w-4 h-4 text-primary-700" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{v.member_name}</p>
                  <p className="text-xs text-gray-500">{v.email}</p>
                </div>
              </div>
              <div className="space-y-1 text-xs text-gray-500">
                <p><span className="font-medium text-gray-700">Skills:</span> {v.skills || '—'}</p>
                <p><span className="font-medium text-gray-700">Availability:</span> {v.availability || '—'}</p>
              </div>
            </div>
          ))}
          {volunteers.length === 0 && <p className="col-span-3 text-center text-gray-400 py-16">No volunteers yet.</p>}
        </div>
      )}

      {tab === 'assignments' && (
        <div className="card p-0 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="table-header">Volunteer</th>
                  <th className="table-header">Event</th>
                  <th className="table-header">Role</th>
                  <th className="table-header hidden md:table-cell">Schedule</th>
                  <th className="table-header">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {assignments.length === 0
                  ? <tr><td colSpan={5} className="text-center py-10 text-gray-400">No assignments found.</td></tr>
                  : assignments.map(a => (
                    <tr key={a.id} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{a.volunteer_name}</td>
                      <td className="table-cell">{a.event_title}</td>
                      <td className="table-cell">{a.role}</td>
                      <td className="table-cell hidden md:table-cell">{a.schedule ? new Date(a.schedule).toLocaleString('en-PH') : '—'}</td>
                      <td className="table-cell"><span className={statusBadge(a.status)}>{a.status}</span></td>
                    </tr>
                  ))
                }
              </tbody>
            </table>
          </div>
        </div>
      )}

      {volModal && <VolunteerModal members={members} onSave={async form => { try { await api.post('/volunteers', form); toast.success('Volunteer registered.'); load(); setVolModal(false); } catch(e) { toast.error(e.response?.data?.message||'Error.'); }}} onClose={() => setVolModal(false)} />}
      {assModal && <AssignModal volunteers={volunteers} events={events} onSave={async form => { try { await api.post('/volunteers/assignments', form); toast.success('Assigned.'); load(); setAssModal(false); } catch(e) { toast.error(e.response?.data?.message||'Error.'); }}} onClose={() => setAssModal(false)} />}
    </div>
  );
}

function VolunteerModal({ members, onSave, onClose }) {
  const [form, setForm] = useState({ member_id:'', skills:'', availability:'' });
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl w-full max-w-md shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b"><h3 className="font-semibold text-lg">Register Volunteer</h3><button onClick={onClose}><FiX className="w-5 h-5 text-gray-400" /></button></div>
        <div className="p-6 space-y-4">
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Member *</label>
            <select className="select" value={form.member_id} onChange={e=>setForm(p=>({...p,member_id:e.target.value}))}>
              <option value="">— Select Member —</option>
              {members.map(m=><option key={m.id} value={m.id}>{m.first_name} {m.last_name}</option>)}
            </select>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Skills</label><input className="input" value={form.skills} onChange={e=>setForm(p=>({...p,skills:e.target.value}))} /></div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Availability</label><input className="input" value={form.availability} onChange={e=>setForm(p=>({...p,availability:e.target.value}))} /></div>
        </div>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => onSave(form)} className="btn-primary">Save</button>
        </div>
      </div>
    </div>
  );
}

function AssignModal({ volunteers, events, onSave, onClose }) {
  const [form, setForm] = useState({ volunteer_id:'', event_id:'', role:'', schedule:'', notes:'' });
  const ROLES = ['Usher','Multimedia Team','Choir Assistant','Event Organizer','Security','Greeter','Food Service','Prayer Team'];
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl w-full max-w-md shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b"><h3 className="font-semibold text-lg">Assign Volunteer</h3><button onClick={onClose}><FiX className="w-5 h-5 text-gray-400" /></button></div>
        <div className="p-6 space-y-4">
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Volunteer *</label>
            <select className="select" value={form.volunteer_id} onChange={e=>setForm(p=>({...p,volunteer_id:e.target.value}))}>
              <option value="">— Select —</option>
              {volunteers.map(v=><option key={v.id} value={v.id}>{v.member_name}</option>)}
            </select>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Event *</label>
            <select className="select" value={form.event_id} onChange={e=>setForm(p=>({...p,event_id:e.target.value}))}>
              <option value="">— Select —</option>
              {events.map(e=><option key={e.id} value={e.id}>{e.title}</option>)}
            </select>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Role *</label>
            <select className="select" value={form.role} onChange={e=>setForm(p=>({...p,role:e.target.value}))}>
              <option value="">— Select —</option>
              {ROLES.map(r=><option key={r}>{r}</option>)}
            </select>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Schedule</label><input type="datetime-local" className="input" value={form.schedule} onChange={e=>setForm(p=>({...p,schedule:e.target.value}))} /></div>
        </div>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => onSave(form)} className="btn-primary">Assign</button>
        </div>
      </div>
    </div>
  );
}
