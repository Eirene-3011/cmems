import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiEdit2, FiTrash2, FiX, FiUsers } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

const EMPTY = { name:'', description:'', leader_id:'', status:'Active' };

export default function Ministries() {
  const { user }                  = useAuth();
  const [ministries, setMinistries] = useState([]);
  const [members, setMembers]     = useState([]);
  const [modal, setModal]         = useState(null);
  const [loading, setLoading]     = useState(true);

  const isAdmin = user?.role === 'Super Administrator';

  async function load() {
    setLoading(true);
    try {
      const [mr, ms] = await Promise.all([api.get('/ministries'), api.get('/members')]);
      setMinistries(mr.data.data);
      setMembers(ms.data.data);
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  async function save(form) {
    try {
      if (form.id) await api.put(`/ministries/${form.id}`, form);
      else         await api.post('/ministries', form);
      toast.success('Saved.'); setModal(null); load();
    } catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  async function remove(id) {
    if (!confirm('Delete this ministry?')) return;
    try { await api.delete(`/ministries/${id}`); toast.success('Deleted.'); load(); }
    catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Ministries</h1>
        {isAdmin && <button onClick={() => setModal(EMPTY)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Add Ministry</button>}
      </div>

      {loading
        ? <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600" /></div>
        : <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {ministries.map(m => (
              <div key={m.id} className="card hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="bg-primary-100 rounded-lg p-2"><FiUsers className="w-5 h-5 text-primary-700" /></div>
                  <span className={m.status === 'Active' ? 'badge-green' : 'badge-red'}>{m.status}</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">{m.name}</h3>
                <p className="text-sm text-gray-500 mb-3 line-clamp-2">{m.description || 'No description.'}</p>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">Leader: <span className="font-medium text-gray-700">{m.leader_name || '—'}</span></span>
                  <span className="badge badge-blue">{m.member_count} members</span>
                </div>
                {isAdmin && (
                  <div className="flex gap-2 mt-4 pt-4 border-t">
                    <button onClick={() => setModal(m)} className="btn-secondary flex-1 flex items-center justify-center gap-1 py-1.5 text-sm"><FiEdit2 className="w-3.5 h-3.5" /> Edit</button>
                    <button onClick={() => remove(m.id)} className="btn-danger flex items-center justify-center gap-1 px-3 py-1.5 text-sm"><FiTrash2 className="w-3.5 h-3.5" /></button>
                  </div>
                )}
              </div>
            ))}
          </div>
      }

      {modal && (
        <MinistryModal form={modal} members={members} onSave={save} onClose={() => setModal(null)} />
      )}
    </div>
  );
}

function MinistryModal({ form: init, members, onSave, onClose }) {
  const [form, setForm] = useState(init);
  const set = f => setForm(p => ({ ...p, ...f }));
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h3 className="font-semibold text-lg">{form.id ? 'Edit Ministry' : 'Add Ministry'}</h3>
          <button onClick={onClose}><FiX className="w-5 h-5 text-gray-400 hover:text-gray-600" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Name *</label><input className="input" required value={form.name} onChange={e=>set({name:e.target.value})} /></div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Description</label><textarea className="input" rows={3} value={form.description||''} onChange={e=>set({description:e.target.value})} /></div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Leader</label>
            <select className="select" value={form.leader_id||''} onChange={e=>set({leader_id:e.target.value||null})}>
              <option value="">— Select Leader —</option>
              {members.map(m => <option key={m.id} value={m.id}>{m.first_name} {m.last_name}</option>)}
            </select>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Status</label>
            <select className="select" value={form.status} onChange={e=>set({status:e.target.value})}>
              <option>Active</option><option>Inactive</option>
            </select>
          </div>
        </div>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => onSave(form)} className="btn-primary">Save</button>
        </div>
      </div>
    </div>
  );
}
