import { useEffect, useState } from 'react';
import api from '../services/api';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';

export default function Reports() {
  const [data, setData]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard/reports/ministry-participation')
      .then(r => setData(r.data.data))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const byMinistry = data.reduce((acc, row) => {
    if (!acc[row.ministry_name]) acc[row.ministry_name] = { name: row.ministry_name, total_members: 0, avg_rate: 0, rates: [] };
    acc[row.ministry_name].total_members++;
    acc[row.ministry_name].rates.push(parseFloat(row.attendance_rate || 0));
    return acc;
  }, {});

  const chartData = Object.values(byMinistry).map(m => ({
    name: m.name,
    members: m.total_members,
    avg_attendance: m.rates.length ? Math.round(m.rates.reduce((s,r)=>s+r,0)/m.rates.length) : 0,
  }));

  return (
    <div className="space-y-6">
      <h1 className="page-title">Reports & Analytics</h1>

      {/* Ministry participation chart */}
      <div className="card">
        <h2 className="section-title">Ministry Participation Overview</h2>
        {loading
          ? <div className="flex justify-center py-10"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600" /></div>
          : <ResponsiveContainer width="100%" height={280}>
              <BarChart data={chartData} margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="left"  orientation="left"  tick={{ fontSize: 11 }} label={{ value: 'Members', angle: -90, position: 'insideLeft', style: { fontSize: 11 } }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} tickFormatter={v=>`${v}%`} label={{ value: 'Avg Att%', angle: 90, position: 'insideRight', style: { fontSize: 11 } }} />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left"  dataKey="members"         name="Members"            fill="#2563eb" radius={[4,4,0,0]} />
                <Bar yAxisId="right" dataKey="avg_attendance"  name="Avg Attendance %"   fill="#f59e0b" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
        }
      </div>

      {/* Detail table */}
      <div className="card p-0 overflow-hidden">
        <div className="px-6 py-4 border-b"><h2 className="font-semibold text-gray-800">Ministry Participation Dashboard (vw_ministry_participation_dashboard)</h2></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="table-header">Member Name</th>
                <th className="table-header">Ministry</th>
                <th className="table-header">Role</th>
                <th className="table-header">Events Attended</th>
                <th className="table-header">Attendance Rate</th>
                <th className="table-header">Last Participation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading
                ? <tr><td colSpan={6} className="text-center py-10 text-gray-400">Loading…</td></tr>
                : data.length === 0
                  ? <tr><td colSpan={6} className="text-center py-10 text-gray-400">No data.</td></tr>
                  : data.map((r, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{r.member_name}</td>
                      <td className="table-cell">{r.ministry_name}</td>
                      <td className="table-cell">{r.ministry_role}</td>
                      <td className="table-cell text-center">{r.total_events_attended}</td>
                      <td className="table-cell">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                            <div className="bg-primary-600 h-1.5 rounded-full" style={{ width: `${Math.min(r.attendance_rate, 100)}%` }} />
                          </div>
                          <span className="text-xs w-10">{r.attendance_rate}%</span>
                        </div>
                      </td>
                      <td className="table-cell text-gray-500">{r.last_participation_date ? new Date(r.last_participation_date).toLocaleDateString('en-PH') : '—'}</td>
                    </tr>
                  ))
              }
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t text-xs text-gray-400">Data sourced from MySQL View: vw_ministry_participation_dashboard</div>
      </div>
    </div>
  );
}
