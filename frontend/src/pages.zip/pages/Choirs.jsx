import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiX, FiMusic } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

const EMPTY = { name:'', description:'', coordinator_id:'', status:'Active' };

export default function Choirs() {
  const { user }            = useAuth();
  const [choirs, setChoirs] = useState([]);
  const [members, setMembers] = useState([]);
  const [modal, setModal]   = useState(null);
  const [loading, setLoading] = useState(true);

  const canWrite = ['Super Administrator','Choir Coordinator'].includes(user?.role);

  async function load() {
    setLoading(true);
    const [cr, mr] = await Promise.all([api.get('/choirs'), api.get('/members')]);
    setChoirs(cr.data.data);
    setMembers(mr.data.data);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function save(form) {
    try {
      if (form.id) await api.put(`/choirs/${form.id}`, form);
      else         await api.post('/choirs', form);
      toast.success('Saved.'); setModal(null); load();
    } catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  async function remove(id) {
    if (!confirm('Delete choir?')) return;
    try { await api.delete(`/choirs/${id}`); toast.success('Deleted.'); load(); }
    catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Choirs</h1>
        {canWrite && <button onClick={() => setModal(EMPTY)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Add Choir</button>}
      </div>

      {loading
        ? <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600" /></div>
        : <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {choirs.length === 0 && <p className="col-span-3 text-center text-gray-400 py-16">No choirs yet.</p>}
            {choirs.map(c => (
              <div key={c.id} className="card hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-purple-100 rounded-lg p-2"><FiMusic className="w-5 h-5 text-purple-700" /></div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{c.name}</h3>
                    <p className="text-xs text-gray-500">Coordinator: {c.coordinator_name || '—'}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-500 mb-3">{c.description || 'No description.'}</p>
                <div className="flex items-center justify-between text-sm">
                  <span className={c.status === 'Active' ? 'badge-green' : 'badge-red'}>{c.status}</span>
                  <span className="badge badge-purple">{c.member_count} members</span>
                </div>
                {canWrite && (
                  <div className="flex gap-2 mt-4 pt-4 border-t">
                    <button onClick={() => setModal(c)} className="btn-secondary flex-1 text-sm py-1.5">Edit</button>
                    <button onClick={() => remove(c.id)} className="btn-danger px-3 py-1.5 text-sm">Del</button>
                  </div>
                )}
              </div>
            ))}
          </div>
      }

      {modal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-md shadow-xl">
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h3 className="font-semibold text-lg">{modal.id ? 'Edit Choir' : 'Add Choir'}</h3>
              <button onClick={() => setModal(null)}><FiX className="w-5 h-5 text-gray-400" /></button>
            </div>
            <ChoirForm init={modal} members={members} onSave={save} onCancel={() => setModal(null)} />
          </div>
        </div>
      )}
    </div>
  );
}

function ChoirForm({ init, members, onSave, onCancel }) {
  const [form, setForm] = useState({ ...EMPTY, ...init });
  const set = f => setForm(p => ({ ...p, ...f }));
  return (
    <>
      <div className="p-6 space-y-4">
        <div><label className="text-xs font-medium text-gray-600 block mb-1">Name *</label><input className="input" value={form.name} onChange={e=>set({name:e.target.value})} /></div>
        <div><label className="text-xs font-medium text-gray-600 block mb-1">Description</label><textarea className="input" rows={2} value={form.description||''} onChange={e=>set({description:e.target.value})} /></div>
        <div><label className="text-xs font-medium text-gray-600 block mb-1">Coordinator</label>
          <select className="select" value={form.coordinator_id||''} onChange={e=>set({coordinator_id:e.target.value||null})}>
            <option value="">— Select —</option>
            {members.map(m => <option key={m.id} value={m.id}>{m.first_name} {m.last_name}</option>)}
          </select>
        </div>
        <div><label className="text-xs font-medium text-gray-600 block mb-1">Status</label>
          <select className="select" value={form.status} onChange={e=>set({status:e.target.value})}>
            <option>Active</option><option>Inactive</option>
          </select>
        </div>
      </div>
      <div className="px-6 py-4 border-t flex justify-end gap-2">
        <button onClick={onCancel} className="btn-secondary">Cancel</button>
        <button onClick={() => onSave(form)} className="btn-primary">Save</button>
      </div>
    </>
  );
}
