import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiX } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

function statusBadge(s) {
  if (s === 'Present') return 'badge-green';
  if (s === 'Absent')  return 'badge-red';
  return 'badge-yellow';
}

export default function Attendance() {
  const { user }                  = useAuth();
  const [attendance, setAttendance] = useState([]);
  const [events, setEvents]       = useState([]);
  const [members, setMembers]     = useState([]);
  const [filterEvent, setFilterEvent] = useState('');
  const [modal, setModal]         = useState(false);
  const [loading, setLoading]     = useState(true);

  const canWrite = ['Super Administrator','Ministry Leader','Choir Coordinator'].includes(user?.role);

  async function load() {
    setLoading(true);
    try {
      const [ar, er, mr] = await Promise.all([
        api.get('/attendance', { params: filterEvent ? { event_id: filterEvent } : {} }),
        api.get('/events'),
        api.get('/members'),
      ]);
      setAttendance(ar.data.data);
      setEvents(er.data.data);
      setMembers(mr.data.data);
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [filterEvent]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Attendance</h1>
        {canWrite && <button onClick={() => setModal(true)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Record Attendance</button>}
      </div>

      <div className="card p-4">
        <label className="text-sm font-medium text-gray-600 block mb-1">Filter by Event</label>
        <select className="select w-full sm:w-72" value={filterEvent} onChange={e => setFilterEvent(e.target.value)}>
          <option value="">— All Events —</option>
          {events.map(e => <option key={e.id} value={e.id}>{e.title} — {new Date(e.start_date).toLocaleDateString('en-PH')}</option>)}
        </select>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="table-header">Member</th>
                <th className="table-header">Event</th>
                <th className="table-header">Date</th>
                <th className="table-header">Status</th>
                <th className="table-header hidden md:table-cell">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading
                ? <tr><td colSpan={5} className="text-center py-10 text-gray-400">Loading…</td></tr>
                : attendance.length === 0
                  ? <tr><td colSpan={5} className="text-center py-10 text-gray-400">No attendance records found.</td></tr>
                  : attendance.map(a => (
                    <tr key={a.id} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{a.member_name}</td>
                      <td className="table-cell">{a.event_title}</td>
                      <td className="table-cell whitespace-nowrap">{a.attendance_date ? new Date(a.attendance_date).toLocaleDateString('en-PH') : '—'}</td>
                      <td className="table-cell"><span className={statusBadge(a.status)}>{a.status}</span></td>
                      <td className="table-cell hidden md:table-cell text-gray-500">{a.notes || '—'}</td>
                    </tr>
                  ))
              }
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t text-sm text-gray-500">{attendance.length} record(s)</div>
      </div>

      {modal && <RecordModal events={events} members={members} onSave={() => { setModal(false); load(); }} onClose={() => setModal(false)} />}
    </div>
  );
}

function RecordModal({ events, members, onSave, onClose }) {
  const [eventId, setEventId]   = useState('');
  const [date, setDate]         = useState(new Date().toISOString().slice(0,10));
  const [rows, setRows]         = useState([]);
  const [saving, setSaving]     = useState(false);

  function initRows() {
    if (!eventId || !members.length) return;
    setRows(members.map(m => ({ event_id: parseInt(eventId), member_id: m.id, member_name: `${m.first_name} ${m.last_name}`, attendance_date: date, status: 'Present', notes: '' })));
  }

  useEffect(() => { initRows(); }, [eventId, date]);

  function setRow(i, key, val) {
    setRows(prev => { const n = [...prev]; n[i] = { ...n[i], [key]: val }; return n; });
  }

  async function save() {
    if (!eventId) { toast.error('Select an event first.'); return; }
    if (!rows.length) { toast.error('No members to record.'); return; }
    setSaving(true);
    try {
      await api.post('/attendance', { records: rows });
      toast.success('Attendance recorded.'); onSave();
    } catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h3 className="font-semibold text-lg">Record Attendance</h3>
          <button onClick={onClose}><FiX className="w-5 h-5 text-gray-400 hover:text-gray-600" /></button>
        </div>
        <div className="p-6 space-y-4 flex-shrink-0">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">Event *</label>
              <select className="select" value={eventId} onChange={e => setEventId(e.target.value)}>
                <option value="">— Select Event —</option>
                {events.map(e => <option key={e.id} value={e.id}>{e.title}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">Attendance Date *</label>
              <input type="date" className="input" value={date} onChange={e => setDate(e.target.value)} />
            </div>
          </div>
        </div>
        {rows.length > 0 && (
          <div className="flex-1 overflow-y-auto border-t">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 sticky top-0">
                <tr>
                  <th className="table-header">Member</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {rows.map((r, i) => (
                  <tr key={r.member_id}>
                    <td className="table-cell font-medium">{r.member_name}</td>
                    <td className="table-cell">
                      <select className="select text-xs py-1" value={r.status} onChange={e => setRow(i,'status',e.target.value)}>
                        <option>Present</option><option>Absent</option><option>Excused</option>
                      </select>
                    </td>
                    <td className="table-cell"><input className="input text-xs py-1" value={r.notes} onChange={e => setRow(i,'notes',e.target.value)} placeholder="Optional notes" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={save} disabled={saving || !eventId} className="btn-primary">{saving ? 'Saving…' : 'Save Attendance'}</button>
        </div>
      </div>
    </div>
  );
}
