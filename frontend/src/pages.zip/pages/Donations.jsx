import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiX, FiDollarSign } from 'react-icons/fi';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const TYPES = ['Tithes','Offerings','Building Fund','Missions Fund','Special Offering'];
const COLORS = { Tithes:'#2563eb', Offerings:'#10b981', 'Building Fund':'#f59e0b', 'Missions Fund':'#8b5cf6', 'Special Offering':'#ef4444' };
const EMPTY = { member_id:'', donor_name:'', amount:'', donation_date: new Date().toISOString().slice(0,10), donation_type:'Tithes', remarks:'' };

export default function Donations() {
  const [donations, setDonations] = useState([]);
  const [members, setMembers]     = useState([]);
  const [monthly, setMonthly]     = useState([]);
  const [modal, setModal]         = useState(false);
  const [typeFilter, setTypeFilter] = useState('');
  const [loading, setLoading]     = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [dr, mr, mo] = await Promise.all([
        api.get('/donations', { params: typeFilter ? { type: typeFilter } : {} }),
        api.get('/members'),
        api.get('/donations/monthly'),
      ]);
      setDonations(dr.data.data);
      setMembers(mr.data.data);

      // transform monthly data for recharts
      const map = {};
      mo.data.data.forEach(r => {
        if (!map[r.month]) map[r.month] = { month: r.month };
        map[r.month][r.donation_type] = parseFloat(r.total);
      });
      setMonthly(Object.values(map).sort((a,b) => a.month.localeCompare(b.month)));
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [typeFilter]);

  const totalAmount = donations.reduce((s, d) => s + parseFloat(d.amount || 0), 0);
  const formatPHP = v => `₱${Number(v).toLocaleString('en-PH', { minimumFractionDigits: 2 })}`;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Donations</h1>
        <button onClick={() => setModal(true)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Record Donation</button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {TYPES.map(t => {
          const total = donations.filter(d=>d.donation_type===t).reduce((s,d)=>s+parseFloat(d.amount||0),0);
          return (
            <div key={t} className="card text-center p-4">
              <p className="text-xs text-gray-500 mb-1">{t}</p>
              <p className="font-bold text-gray-900 text-lg">{formatPHP(total)}</p>
            </div>
          );
        })}
      </div>

      {/* Chart */}
      {monthly.length > 0 && (
        <div className="card">
          <h2 className="section-title">Monthly Donation Trends</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `₱${(v/1000).toFixed(0)}k`} />
              <Tooltip formatter={v => formatPHP(v)} />
              <Legend />
              {TYPES.map(t => <Bar key={t} dataKey={t} fill={COLORS[t]} radius={[3,3,0,0]} stackId="a" />)}
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Filter + Table */}
      <div className="card p-4">
        <select className="select w-full sm:w-56" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
          <option value="">— All Types —</option>
          {TYPES.map(t=><option key={t}>{t}</option>)}
        </select>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="table-header">Donor</th>
                <th className="table-header">Type</th>
                <th className="table-header">Amount</th>
                <th className="table-header hidden md:table-cell">Date</th>
                <th className="table-header hidden lg:table-cell">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading
                ? <tr><td colSpan={5} className="text-center py-10 text-gray-400">Loading…</td></tr>
                : donations.map(d => (
                  <tr key={d.id} className="hover:bg-gray-50">
                    <td className="table-cell font-medium">{d.member_name || d.donor_name || 'Anonymous'}</td>
                    <td className="table-cell"><span className="badge badge-blue text-xs">{d.donation_type}</span></td>
                    <td className="table-cell font-semibold text-green-700">{formatPHP(d.amount)}</td>
                    <td className="table-cell hidden md:table-cell whitespace-nowrap">{d.donation_date ? new Date(d.donation_date).toLocaleDateString('en-PH') : '—'}</td>
                    <td className="table-cell hidden lg:table-cell text-gray-500">{d.remarks || '—'}</td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t text-sm text-gray-500 flex justify-between">
          <span>{donations.length} record(s)</span>
          <span className="font-semibold text-green-700">Total: {formatPHP(totalAmount)}</span>
        </div>
      </div>

      {modal && (
        <DonationModal members={members} onSave={async form => {
          try { await api.post('/donations', form); toast.success('Donation recorded.'); load(); setModal(false); }
          catch(e) { toast.error(e.response?.data?.message||'Error.'); }
        }} onClose={() => setModal(false)} />
      )}
    </div>
  );
}

function DonationModal({ members, onSave, onClose }) {
  const [form, setForm] = useState(EMPTY);
  const set = f => setForm(p => ({ ...p, ...f }));
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl w-full max-w-md shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b"><h3 className="font-semibold text-lg">Record Donation</h3><button onClick={onClose}><FiX className="w-5 h-5 text-gray-400" /></button></div>
        <div className="p-6 space-y-4">
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Member (leave blank for anonymous)</label>
            <select className="select" value={form.member_id} onChange={e=>set({member_id:e.target.value})}>
              <option value="">— Anonymous / Walk-in —</option>
              {members.map(m=><option key={m.id} value={m.id}>{m.first_name} {m.last_name}</option>)}
            </select>
          </div>
          {!form.member_id && <div><label className="text-xs font-medium text-gray-600 block mb-1">Donor Name</label><input className="input" value={form.donor_name} onChange={e=>set({donor_name:e.target.value})} /></div>}
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Amount (₱) *</label><input type="number" step="0.01" min="1" className="input" required value={form.amount} onChange={e=>set({amount:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Date</label><input type="date" className="input" value={form.donation_date} onChange={e=>set({donation_date:e.target.value})} /></div>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Type *</label>
            <select className="select" value={form.donation_type} onChange={e=>set({donation_type:e.target.value})}>
              {TYPES.map(t=><option key={t}>{t}</option>)}
            </select>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Remarks</label><textarea className="input" rows={2} value={form.remarks} onChange={e=>set({remarks:e.target.value})} /></div>
        </div>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => onSave(form)} className="btn-primary">Save</button>
        </div>
      </div>
    </div>
  );
}
