import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiX } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

const ROLES = [
  { id: 1, name: 'Super Administrator' },
  { id: 2, name: 'Ministry Leader' },
  { id: 3, name: 'Choir Coordinator' },
  { id: 4, name: 'Volunteer' },
  { id: 5, name: 'Church Member' },
];

export default function Users() {
  const { user }        = useAuth();
  const [users, setUsers] = useState([]);
  const [modal, setModal] = useState(false);
  const [loading, setLoading] = useState(true);

  if (user?.role !== 'Super Administrator') {
    return <div className="text-center py-20 text-gray-400">Access restricted.</div>;
  }

  async function load() {
    setLoading(true);
    try { const r = await api.get('/dashboard/users'); setUsers(r.data.data); }
    finally { setLoading(false); }
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">User Management</h1>
        <button onClick={() => setModal(true)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Add User</button>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="table-header">#</th>
                <th className="table-header">Name</th>
                <th className="table-header">Email</th>
                <th className="table-header">Role</th>
                <th className="table-header">Status</th>
                <th className="table-header hidden md:table-cell">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading
                ? <tr><td colSpan={6} className="text-center py-10 text-gray-400">Loading…</td></tr>
                : users.map((u, i) => (
                  <tr key={u.id} className="hover:bg-gray-50">
                    <td className="table-cell text-gray-400">{i + 1}</td>
                    <td className="table-cell font-medium">{u.first_name} {u.last_name}</td>
                    <td className="table-cell">{u.email}</td>
                    <td className="table-cell"><span className="badge badge-blue">{u.role}</span></td>
                    <td className="table-cell"><span className={u.status === 'Active' ? 'badge-green' : 'badge-red'}>{u.status}</span></td>
                    <td className="table-cell hidden md:table-cell text-gray-400">{new Date(u.created_at).toLocaleDateString('en-PH')}</td>
                  </tr>
                ))
              }
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t text-sm text-gray-500">{users.length} user(s)</div>
      </div>

      {modal && (
        <RegisterModal onSave={async form => {
          try { await api.post('/auth/register', form); toast.success('User registered.'); load(); setModal(false); }
          catch(e) { toast.error(e.response?.data?.message || 'Error.'); }
        }} onClose={() => setModal(false)} />
      )}
    </div>
  );
}

function RegisterModal({ onSave, onClose }) {
  const [form, setForm] = useState({ first_name:'', last_name:'', email:'', password:'', role_id: 5 });
  const set = f => setForm(p => ({ ...p, ...f }));
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl w-full max-w-md shadow-xl">
        <div className="flex items-center justify-between px-6 py-4 border-b"><h3 className="font-semibold text-lg">Add User</h3><button onClick={onClose}><FiX className="w-5 h-5 text-gray-400" /></button></div>
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">First Name *</label><input className="input" value={form.first_name} onChange={e=>set({first_name:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Last Name *</label><input className="input" value={form.last_name} onChange={e=>set({last_name:e.target.value})} /></div>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Email *</label><input type="email" className="input" value={form.email} onChange={e=>set({email:e.target.value})} /></div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Password *</label><input type="password" className="input" value={form.password} onChange={e=>set({password:e.target.value})} /></div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Role *</label>
            <select className="select" value={form.role_id} onChange={e=>set({role_id:parseInt(e.target.value)})}>
              {ROLES.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}
            </select>
          </div>
        </div>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => onSave(form)} className="btn-primary">Register</button>
        </div>
      </div>
    </div>
  );
}
