import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiEdit2, FiTrash2, FiX, FiCalendar, FiMapPin } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

const TYPES = ['Sunday Worship','Bible Study','Youth Camp','Retreat','Choir Practice','Special Event','Outreach','Conference'];
const STATUSES = ['Upcoming','Ongoing','Completed','Cancelled'];
const EMPTY = { title:'', description:'', event_type:'Sunday Worship', venue:'', start_date:'', end_date:'', capacity:'', status:'Upcoming' };

function statusBadge(s) {
  if (s === 'Upcoming')  return 'badge-blue';
  if (s === 'Ongoing')   return 'badge-yellow';
  if (s === 'Completed') return 'badge-green';
  return 'badge-gray';
}

export default function Events() {
  const { user }          = useAuth();
  const [events, setEvents] = useState([]);
  const [filter, setFilter] = useState('');
  const [modal, setModal]   = useState(null);
  const [loading, setLoading] = useState(true);

  const canWrite = ['Super Administrator','Ministry Leader'].includes(user?.role);
  const isAdmin  = user?.role === 'Super Administrator';

  async function load() {
    setLoading(true);
    try {
      const r = await api.get('/events', { params: filter ? { status: filter } : {} });
      setEvents(r.data.data);
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [filter]);

  async function save(form) {
    try {
      if (form.id) await api.put(`/events/${form.id}`, form);
      else         await api.post('/events', form);
      toast.success('Saved.'); setModal(null); load();
    } catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  async function remove(id) {
    if (!confirm('Delete this event?')) return;
    try { await api.delete(`/events/${id}`); toast.success('Deleted.'); load(); }
    catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Events</h1>
        {canWrite && <button onClick={() => setModal(EMPTY)} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Create Event</button>}
      </div>

      <div className="card p-4 flex flex-wrap gap-2">
        {['','Upcoming','Ongoing','Completed','Cancelled'].map(s => (
          <button key={s} onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${filter === s ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
            {s || 'All'}
          </button>
        ))}
      </div>

      {loading
        ? <div className="flex justify-center py-20"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600" /></div>
        : <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {events.length === 0 && <p className="text-gray-400 col-span-3 text-center py-16">No events found.</p>}
            {events.map(ev => (
              <div key={ev.id} className="card hover:shadow-md transition-shadow flex flex-col">
                <div className="flex items-start justify-between mb-2">
                  <span className="badge badge-purple text-xs">{ev.event_type}</span>
                  <span className={statusBadge(ev.status)}>{ev.status}</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">{ev.title}</h3>
                <p className="text-sm text-gray-500 line-clamp-2 mb-3 flex-1">{ev.description || 'No description.'}</p>
                <div className="space-y-1 text-xs text-gray-500 border-t pt-3 mt-auto">
                  <div className="flex items-center gap-1.5"><FiCalendar className="w-3.5 h-3.5" />{new Date(ev.start_date).toLocaleString('en-PH',{dateStyle:'medium',timeStyle:'short'})}</div>
                  {ev.venue && <div className="flex items-center gap-1.5"><FiMapPin className="w-3.5 h-3.5" />{ev.venue}</div>}
                  <div className="flex items-center justify-between mt-2">
                    <span>Capacity: {ev.capacity ?? 'Unlimited'}</span>
                    <span>Attendees: <strong>{ev.total_attendees}</strong> ({ev.attendance_percentage}%)</span>
                  </div>
                </div>
                {(canWrite || isAdmin) && (
                  <div className="flex gap-2 mt-4 pt-4 border-t">
                    {canWrite && <button onClick={() => setModal(ev)} className="btn-secondary flex-1 flex items-center justify-center gap-1 py-1.5 text-sm"><FiEdit2 className="w-3.5 h-3.5" /> Edit</button>}
                    {isAdmin  && <button onClick={() => remove(ev.id)} className="btn-danger flex items-center justify-center gap-1 px-3 py-1.5 text-sm"><FiTrash2 className="w-3.5 h-3.5" /></button>}
                  </div>
                )}
              </div>
            ))}
          </div>
      }

      {modal && <EventModal form={modal} onSave={save} onClose={() => setModal(null)} />}
    </div>
  );
}

function EventModal({ form: init, onSave, onClose }) {
  const [form, setForm] = useState({ ...EMPTY, ...init });
  const set = f => setForm(p => ({ ...p, ...f }));

  function fmt(dt) { return dt ? new Date(dt).toISOString().slice(0,16) : ''; }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h3 className="font-semibold text-lg">{form.id ? 'Edit Event' : 'Create Event'}</h3>
          <button onClick={onClose}><FiX className="w-5 h-5 text-gray-400 hover:text-gray-600" /></button>
        </div>
        <div className="overflow-y-auto p-6 space-y-4">
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Title *</label><input className="input" required value={form.title} onChange={e=>set({title:e.target.value})} /></div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Description</label><textarea className="input" rows={2} value={form.description||''} onChange={e=>set({description:e.target.value})} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Type *</label>
              <select className="select" value={form.event_type} onChange={e=>set({event_type:e.target.value})}>
                {TYPES.map(t=><option key={t}>{t}</option>)}
              </select>
            </div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Status</label>
              <select className="select" value={form.status} onChange={e=>set({status:e.target.value})}>
                {STATUSES.map(s=><option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Venue</label><input className="input" value={form.venue||''} onChange={e=>set({venue:e.target.value})} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Start Date *</label><input type="datetime-local" className="input" required value={fmt(form.start_date)} onChange={e=>set({start_date:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">End Date *</label><input type="datetime-local" className="input" required value={fmt(form.end_date)} onChange={e=>set({end_date:e.target.value})} /></div>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Capacity</label><input type="number" min="1" className="input" value={form.capacity||''} onChange={e=>set({capacity:e.target.value})} placeholder="Leave blank for unlimited" /></div>
        </div>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={() => onSave(form)} className="btn-primary">Save</button>
        </div>
      </div>
    </div>
  );
}
