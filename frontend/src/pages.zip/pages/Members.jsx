import { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { FiPlus, FiEdit2, FiTrash2, FiSearch, FiX } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';

const EMPTY = { first_name:'', middle_name:'', last_name:'', gender:'Male', birthdate:'', contact_number:'', email:'', address:'', date_joined:'', status:'Active' };

function Modal({ member, onSave, onClose }) {
  const [form, setForm] = useState(member || EMPTY);
  const set = f => setForm(p => ({ ...p, ...f }));

  async function submit(e) {
    e.preventDefault();
    try {
      if (member?.id) await api.put(`/members/${member.id}`, form);
      else            await api.post('/members', form);
      toast.success(member?.id ? 'Member updated.' : 'Member added.');
      onSave();
    } catch (err) { toast.error(err.response?.data?.message || 'Error saving member.'); }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b">
          <h3 className="font-semibold text-lg">{member?.id ? 'Edit Member' : 'Add Member'}</h3>
          <button onClick={onClose}><FiX className="w-5 h-5 text-gray-400 hover:text-gray-600" /></button>
        </div>
        <form onSubmit={submit} className="overflow-y-auto p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">First Name *</label><input className="input" required value={form.first_name} onChange={e=>set({first_name:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Middle Name</label><input className="input" value={form.middle_name} onChange={e=>set({middle_name:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Last Name *</label><input className="input" required value={form.last_name} onChange={e=>set({last_name:e.target.value})} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Gender *</label>
              <select className="select" required value={form.gender} onChange={e=>set({gender:e.target.value})}>
                <option>Male</option><option>Female</option><option>Other</option>
              </select>
            </div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Birthdate</label><input type="date" className="input" value={form.birthdate} onChange={e=>set({birthdate:e.target.value})} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Contact Number</label><input className="input" value={form.contact_number} onChange={e=>set({contact_number:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Email</label><input type="email" className="input" value={form.email} onChange={e=>set({email:e.target.value})} /></div>
          </div>
          <div><label className="text-xs font-medium text-gray-600 block mb-1">Address</label><textarea className="input" rows={2} value={form.address} onChange={e=>set({address:e.target.value})} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Date Joined</label><input type="date" className="input" value={form.date_joined} onChange={e=>set({date_joined:e.target.value})} /></div>
            <div><label className="text-xs font-medium text-gray-600 block mb-1">Status</label>
              <select className="select" value={form.status} onChange={e=>set({status:e.target.value})}>
                <option>Active</option><option>Inactive</option><option>Deceased</option>
              </select>
            </div>
          </div>
        </form>
        <div className="px-6 py-4 border-t flex justify-end gap-2">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={e=>{ e.preventDefault(); document.querySelector('form').requestSubmit(); }} className="btn-primary">Save</button>
        </div>
      </div>
    </div>
  );
}

export default function Members() {
  const { user }              = useAuth();
  const [members, setMembers] = useState([]);
  const [search, setSearch]   = useState('');
  const [modal, setModal]     = useState(null);
  const [loading, setLoading] = useState(true);

  const canWrite = ['Super Administrator','Ministry Leader'].includes(user?.role);
  const canDelete = user?.role === 'Super Administrator';

  async function load() {
    setLoading(true);
    try {
      const r = await api.get('/members', { params: { search: search || undefined } });
      setMembers(r.data.data);
    } catch { toast.error('Failed to load members.'); }
    finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [search]);

  async function remove(id) {
    if (!confirm('Delete this member?')) return;
    try { await api.delete(`/members/${id}`); toast.success('Deleted.'); load(); }
    catch (err) { toast.error(err.response?.data?.message || 'Error.'); }
  }

  const statusBadge = s => s === 'Active' ? 'badge-green' : s === 'Inactive' ? 'badge-red' : 'badge-gray';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="page-title">Members</h1>
        {canWrite && <button onClick={() => setModal({})} className="btn-primary flex items-center gap-2"><FiPlus className="w-4 h-4" /> Add Member</button>}
      </div>

      <div className="card p-4">
        <div className="relative w-full sm:w-72">
          <FiSearch className="absolute left-3 top-2.5 text-gray-400 w-4 h-4" />
          <input className="input pl-9" placeholder="Search by name, email…" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="table-header">Name</th>
                <th className="table-header hidden md:table-cell">Gender</th>
                <th className="table-header hidden lg:table-cell">Contact</th>
                <th className="table-header hidden xl:table-cell">Email</th>
                <th className="table-header hidden md:table-cell">Date Joined</th>
                <th className="table-header">Status</th>
                {(canWrite || canDelete) && <th className="table-header">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading
                ? <tr><td colSpan={7} className="text-center py-10 text-gray-400">Loading…</td></tr>
                : members.length === 0
                  ? <tr><td colSpan={7} className="text-center py-10 text-gray-400">No members found.</td></tr>
                  : members.map(m => (
                    <tr key={m.id} className="hover:bg-gray-50">
                      <td className="table-cell font-medium">{m.first_name} {m.middle_name || ''} {m.last_name}</td>
                      <td className="table-cell hidden md:table-cell">{m.gender}</td>
                      <td className="table-cell hidden lg:table-cell">{m.contact_number || '—'}</td>
                      <td className="table-cell hidden xl:table-cell">{m.email || '—'}</td>
                      <td className="table-cell hidden md:table-cell">{m.date_joined ? new Date(m.date_joined).toLocaleDateString('en-PH') : '—'}</td>
                      <td className="table-cell"><span className={statusBadge(m.status)}>{m.status}</span></td>
                      {(canWrite || canDelete) && (
                        <td className="table-cell">
                          <div className="flex items-center gap-2">
                            {canWrite  && <button onClick={() => setModal(m)} className="p-1.5 rounded hover:bg-blue-50 text-blue-600"><FiEdit2 className="w-4 h-4" /></button>}
                            {canDelete && <button onClick={() => remove(m.id)} className="p-1.5 rounded hover:bg-red-50 text-red-600"><FiTrash2 className="w-4 h-4" /></button>}
                          </div>
                        </td>
                      )}
                    </tr>
                  ))
              }
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 border-t text-sm text-gray-500">{members.length} member(s) found</div>
      </div>

      {modal !== null && <Modal member={modal.id ? modal : null} onSave={() => { setModal(null); load(); }} onClose={() => setModal(null)} />}
    </div>
  );
}
